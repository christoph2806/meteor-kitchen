this.InputDialog = function(options) {
	alert("InputDialog with Materialize frontend is not implemented yet");
};

