import React, { Component } from "react";
import PropTypes from "prop-types";

export const NotFound = () => (
	<a-entity>
		<a-entity material="color: white" text={"text: Page not found"} />
	</a-entity>
);
