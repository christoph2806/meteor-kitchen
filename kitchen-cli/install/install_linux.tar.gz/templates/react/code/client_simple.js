/*IMPORTS*/
/*CLIENT_STARTUP_IMPORTS*/

this.globalOnRendered = function() {
	/*GLOBAL_ON_RENDERED_CODE*/
};

Meteor.startup(function() {
	/*CLIENT_STARTUP_CODE*/
});
