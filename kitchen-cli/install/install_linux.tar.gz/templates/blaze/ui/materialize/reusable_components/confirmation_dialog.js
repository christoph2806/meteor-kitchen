this.ConfirmationDialog = function(options) {
	alert("ConfirmationDialog with Materialize frontend is not implemented yet");
};
