Template.TEMPLATE_NAME.events({

});

Template.TEMPLATE_NAME.helpers({

});
