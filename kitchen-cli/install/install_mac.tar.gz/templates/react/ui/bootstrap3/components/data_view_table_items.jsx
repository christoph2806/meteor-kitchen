export class TEMPLATE_NAME_TABLE_ITEMS extends Component {
	constructor() {
		super();
		this.onToggle = this.onToggle.bind(this);
		this.onEdit = this.onEdit.bind(this);
		this.onDelete = this.onDelete.bind(this);
		this.onSelect = this.onSelect.bind(this);
		/*ITEM_BINDINGS*/
	}

	onToggle(e) {
		e.stopPropagation();
		let self = this;
		let itemId = this.props.data._id;
		let toggleField = $(e.currentTarget).attr("data-field");

		let data = {};
		data[toggleField] = !this.props.data[toggleField];

		Meteor.call("UPDATE_METHOD_NAME", itemId, data, function(err, res) {
			if(err) {
				alert(err);
			}
		});
	}

	onEdit(e) {
		e.stopPropagation();
		let self = this;
		let itemId = this.props.data._id;
		/*EDIT_ROUTE*/
	}

	onDelete(e) {
		e.stopPropagation();
		let self = this;
		let itemId = this.props.data._id;
		ConfirmationDialog({
			message: "DELETE_CONFIRMATION_MESSAGE",
			title: "Delete",
			onYes: function(id) {
				Meteor.call("REMOVE_METHOD_NAME", id, function(err, res) {
					if(err) {
						alert(err);
					}
				});
			},
			onNo: null,
			onCancel: null,
			buttonYesTitle: "Yes",
			buttonNoTitle: "No",
			buttonCancelTitle: null,
			showCancelButton: false,
			payload: itemId
		});
	}

	onSelect(e) {
		e.stopPropagation();
		let self = this;
		let item = this.props.data;
		let itemId = item ? item._id : null;

		/*ON_ITEM_CLICKED_CODE*/
		/*DETAILS_ROUTE*/
	}

	/*EDIT_BUTTON_CLASS_HELPER*/

	/*DELETE_BUTTON_CLASS_HELPER*/

	/*ITEM_ACTIONS_CODE*/

	/*ITEM_ACTIONS_HELPER_CODE*/

	/*EVENTS_CODE*/

	/*HELPERS_CODE*/

	render() {
		return(
			<tr id="dataview-table-items-row">
			</tr>
		);
	}
}
