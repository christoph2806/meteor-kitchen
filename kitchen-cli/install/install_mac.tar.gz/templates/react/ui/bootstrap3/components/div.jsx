<div id="div" className="COMPONENT_CLASS">
/*TEXT*/
</div>
