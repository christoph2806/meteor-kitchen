global.Buffer = global.Buffer || require("buffer").Buffer;
