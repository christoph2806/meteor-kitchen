<CMSContent name="CONTENT_NAME" textIfEmpty="TEXT_IF_EMPTY" containerClass="CONTAINER_CLASS" />
