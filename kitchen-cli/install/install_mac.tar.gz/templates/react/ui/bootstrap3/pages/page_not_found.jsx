import React, { Component } from "react";
import PropTypes from "prop-types";

export const NotFound = () => (
	<div className="container">
		<h2>Page not found</h2>
	</div>
);
