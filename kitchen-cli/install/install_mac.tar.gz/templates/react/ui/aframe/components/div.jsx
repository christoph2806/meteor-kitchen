<div id="div" class="COMPONENT_CLASS">
/*TEXT*/
</div>
