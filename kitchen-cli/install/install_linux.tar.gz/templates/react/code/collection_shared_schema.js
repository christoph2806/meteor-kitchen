global.Schemas = global.Schemas || {};

global.Schemas.COLLECTION_VAR = new SimpleSchema(SIMPLE_SCHEMA);

COLLECTION_VAR.attachSchema(global.Schemas.COLLECTION_VAR);
