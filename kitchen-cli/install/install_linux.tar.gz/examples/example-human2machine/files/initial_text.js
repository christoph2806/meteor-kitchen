initialText = ""+
"I want site with three pages: home, customers and about.\n"+
"In home page I want jumbotron with title: \"This application is written in human language!\", text: \"Human to describe app, machine to write code!\", button url: \"customers\".\n"+
"Please create one collection: customers.\n"+
"In customers collection I want three fields: name, address and e-mail.\n"+
"In customers page I want CRUD for customers collection.\n"+
"In about page I want text: \"This application is written in human language using Meteor Kitchen, source code generator for Meteor\".\n"+
"";
