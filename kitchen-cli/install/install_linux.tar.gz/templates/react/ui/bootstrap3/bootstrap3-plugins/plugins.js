import "./bootstrap-fileinput/fileinput.css";
import "./bootstrap-fileinput/fileinput.js";
import "./bootstrap-fileinput/fileinput_locale_cz.js";
import "./bootstrap-fileinput/fileinput_locale_de.js";
import "./bootstrap-fileinput/fileinput_locale_el.js";
import "./bootstrap-fileinput/fileinput_locale_es.js";
import "./bootstrap-fileinput/fileinput_locale_fr.js";
import "./bootstrap-fileinput/fileinput_locale_hu.js";
import "./bootstrap-fileinput/fileinput_locale_it.js";
import "./bootstrap-fileinput/fileinput_locale_LANG.js";
import "./bootstrap-fileinput/fileinput_locale_nl.js";
import "./bootstrap-fileinput/fileinput_locale_pl.js";
import "./bootstrap-fileinput/fileinput_locale_pt-BR.js";
import "./bootstrap-fileinput/fileinput_locale_pt.js";
import "./bootstrap-fileinput/fileinput_locale_ro.js";
import "./bootstrap-fileinput/fileinput_locale_ru.js";
import "./bootstrap-fileinput/fileinput_locale_sk.js";
import "./bootstrap-fileinput/fileinput_locale_sr.js";
import "./bootstrap-fileinput/fileinput_locale_th.js";
import "./bootstrap-fileinput/fileinput_locale_tr.js";
import "./bootstrap-fileinput/fileinput_locale_uk.js";
import "./bootstrap-fileinput/fileinput_locale_zh.js";


import "./bootstrap-tagsinput/bootstrap-tagsinput.css";
import "./bootstrap-tagsinput/bootstrap-tagsinput.js";

import "./bootstrap-select/bootstrap-select.css";
import "./bootstrap-select/bootstrap-select.js";

import "./bootstrap-datetimepicker/bootstrap-datetimepicker.css";
import "./bootstrap-datetimepicker/bootstrap-datetimepicker.js";
