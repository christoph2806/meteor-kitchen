<li id="menu-item-simple" className="ITEM_CLASS"><a href="ITEM_LINK"><span id="item-icon" className="ICON_CLASS"></span> <span className="item-title">ITEM_TITLE</span></a></li>

<li id="menu-item-dropdown" className="dropdown ITEM_CLASS">
	<a href="#" className="dropdown-toggle" data-toggle="dropdown"><span id="item-icon" className="ICON_CLASS"></span> <span className="item-title">ITEM_TITLE</span> <b className="caret"></b></a>
	<ul id="menu-items" className="dropdown-menu">
	</ul>
</li>

<li id="menu-item-collapse" className="menu-item-collapse ITEM_CLASS">
	<a href="#ITEM_ID" className="dropdown-toggle" data-toggle="collapse"><span id="item-icon" className="ICON_CLASS"></span> <span className="item-title">ITEM_TITLE</span> <b className="caret"></b></a>
	<div id="ITEM_ID" className="collapse">
		<ul id="menu-items" className="COMPONENT_CLASS">
		</ul>
	</div>
</li>
