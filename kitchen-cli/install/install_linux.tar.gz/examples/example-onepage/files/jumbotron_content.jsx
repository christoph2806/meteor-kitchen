<div>
	<h1 id="section-welcome" class="animate a-zoomIn">One Page Site</h1>

	<p>
		This example application is created with <a href="http://www.meteorkitchen.com" target="_blank">Meteor Kitchen</a> - source code generator for <a href="http://www.meteor.com" target="_blank">Meteor.js</a>
	</p>

	<p>
		Source code (input file for generator) is <a href="https://github.com/perak/kitchen-examples/tree/master/example-onepage" target="_blank">here</a>
	</p>

	<a href="#section1" class="btn btn-lg btn-warning animate a-pulse a-infinite">Find out More</a>
</div>
