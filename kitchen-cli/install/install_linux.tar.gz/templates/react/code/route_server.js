Picker.route("ROUTE_URL", function(params, request, response, next) {
	/*ACTION_FUNCTION*/
});
