To build and run this application on your local computer, open terminal and type:

```
meteor-kitchen {{urlFor 'api.getapp.json' applicationId=application._id}} <dest_dir>
cd <dest_dir>
meteor
```
