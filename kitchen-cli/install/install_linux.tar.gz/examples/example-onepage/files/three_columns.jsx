<div class="row text-center">
	<div class="col-md-4">
		<span class="fa-stack fa-4x">
			<i class="fa fa-circle fa-stack-2x text-primary"></i>
			<i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
		</span>
		<h4 class="service-heading">Column 1</h4>
		<p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
	</div>

	<div class="col-md-4">
		<span class="fa-stack fa-4x">
			<i class="fa fa-circle fa-stack-2x text-primary"></i>
			<i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
		</span>
		<h4 class="service-heading">Column 2</h4>
		<p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
	</div>
	<div class="col-md-4">
		<span class="fa-stack fa-4x">
			<i class="fa fa-circle fa-stack-2x text-primary"></i>
			<i class="fa fa-lock fa-stack-1x fa-inverse"></i>
		</span>
		<h4 class="service-heading">Column 3</h4>
		<p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
	</div>
</div>
