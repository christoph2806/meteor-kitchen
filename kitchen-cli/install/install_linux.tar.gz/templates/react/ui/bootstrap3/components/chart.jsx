<div id="COMPONENT_ID" className="COMPONENT_CLASS">
	<Chart data={this.props.data.QUERY_VAR} chartType="CHART_TYPE" valueField="VALUE_FIELD" categoryField="CATEGORY_FIELD" timeSeriesField="TIME_SERIES_FIELD" dateFormat="DATE_FORMAT" />
</div>
